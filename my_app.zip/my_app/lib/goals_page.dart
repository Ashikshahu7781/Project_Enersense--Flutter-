import 'package:flutter/material.dart';

class GoalsPage extends StatelessWidget {
  const GoalsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Energy Goals")),
      body: const Center(
        child: Text(
          "Monthly Budget & Energy Goals",
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
