// lib/main.dart
import 'dart:async';
import 'dart:ui';
import 'dart:math';

import 'package:flutter/material.dart';

import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(const EnergyProApp());
}

class EnergyProApp extends StatelessWidget {
  const EnergyProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EnerSense',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFFFF7ED),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE85A0F)),
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
          bodyLarge: TextStyle(fontSize: 16),
          bodyMedium: TextStyle(fontSize: 14, color: Color(0xFF57534E)),
        ),
      ),
      home: const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});
  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _index = 0;
  final pages = const [HomeScreen(), GoalsPage(), CostPiePage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [const AnimatedBlobsBackground(), pages[_index]]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(
            icon: Icon(Icons.flag_outlined),
            label: 'Goals',
          ),
          NavigationDestination(
            icon: Icon(Icons.pie_chart_outline),
            label: 'Cost',
          ),
        ],
      ),
    );
  }
}

/* ================= Animated Background Blobs ================= */
class AnimatedGlassCard extends StatelessWidget {
  final Widget? child;
  const AnimatedGlassCard({this.child});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.72),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFF3C6A2).withOpacity(0.14),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
            border: Border.all(color: const Color(0xFFFDE7D1)),
          ),
          child: child,
        ),
      ),
    );
  }
}

class AnimatedBlobsBackground extends StatefulWidget {
  const AnimatedBlobsBackground({super.key});
  @override
  State<AnimatedBlobsBackground> createState() =>
      AnimatedBlobsBackgroundState();
}

class AnimatedBlobsBackgroundState extends State<AnimatedBlobsBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 26),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      ignoring: true,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (context, _) {
          final t = _ctrl.value;
          return Stack(
            children: [
              Positioned(
                left: lerpDouble(-140, -60, sin(pi * t) * 0.5 + 0.5)!,
                top: lerpDouble(-120, -40, cos(pi * t) * 0.5 + 0.5)!,
                child: _Blob(
                  size: 420,
                  colors: const [Color(0xFFFEEBC8), Color(0xFFF97316)],
                  blur: 60,
                  opacity: 0.6,
                ),
              ),
              Positioned(
                right: lerpDouble(-160, -80, cos(pi * t) * 0.5 + 0.5)!,
                bottom: lerpDouble(-160, -40, sin(pi * t) * 0.5 + 0.5)!,
                child: _Blob(
                  size: 420,
                  colors: const [Color(0xFFBFDBFE), Color(0xFFFACC15)],
                  blur: 60,
                  opacity: 0.55,
                ),
              ),
              Positioned.fill(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 0, sigmaY: 0),
                  child: Container(color: Colors.transparent),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _Blob extends StatelessWidget {
  final double size;
  final List<Color> colors;
  final double blur;
  final double opacity;

  const _Blob({
    required this.size,
    required this.colors,
    required this.blur,
    required this.opacity,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: opacity,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: colors),
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: const SizedBox(),
        ),
      ),
    );
  }
}

/* ================= HOME (no full-screen blink) ================= */

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Timer _timer;
  DashboardData _data = DashboardData.generateDummy();

  @override
  void initState() {
    super.initState();

    _timer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final d = await _fetchDashboardData();
      setState(() => _data = d);
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  // Dummy fetch (replace with real HTTP)
  static Future<DashboardData> _fetchDashboardData() async {
    await Future.delayed(const Duration(milliseconds: 250));
    return DashboardData.generateDummy();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text('EnerSense'),
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          toolbarHeight: 68,
          foregroundColor: const Color(0xFF1C1917),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
          child: Column(
            children: [
              _HeaderCard(data: _data),
              const SizedBox(height: 14),
              _AnimatedGlassCard(
                child: _StatusRow(
                  title: 'Peak Hour Status',
                  labelWidget: _AnimatedValue(
                    child: Text(
                      _data.isPeak
                          ? 'Peak Hour — High Tariff'
                          : 'Normal Hour — Standard Tariff',
                      key: ValueKey<bool>(_data.isPeak),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  badgeWidget: _BadgedAnimated(
                    keyVal: _data.isPeak.toString(),
                    text: _data.isPeak ? 'PEAK' : 'NORMAL',
                    color: _data.isPeak
                        ? Colors.red.shade600
                        : Colors.green.shade600,
                  ),
                  icon: Icons.schedule,
                ),
              ),
              const SizedBox(height: 10),
              _AnimatedGlassCard(
                child: _StatusRow(
                  title: 'Voltage Status',
                  labelWidget: _AnimatedValue(
                    child: Text(
                      '${_data.voltage.toStringAsFixed(1)} V',
                      key: ValueKey<double>(_data.voltage),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  badgeWidget: _BadgedAnimated(
                    keyVal: _data.voltage.toStringAsFixed(1),
                    text: _data.voltage < 200
                        ? 'LOW'
                        : (_data.voltage > 250 ? 'HIGH' : 'OK'),
                    color: _data.voltage < 200 || _data.voltage > 250
                        ? Colors.orange.shade700
                        : Colors.green.shade600,
                  ),
                  icon: Icons.power,
                ),
              ),
              const SizedBox(height: 10),
              _AnimatedGlassCard(
                child: _StatusRow(
                  title: 'Overload Condition',
                  labelWidget: _AnimatedValue(
                    child: Text(
                      '${_data.power.toStringAsFixed(0)} W',
                      key: ValueKey<double>(_data.power),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  badgeWidget: _BadgedAnimated(
                    keyVal: _data.isOverload.toString(),
                    text: _data.isOverload ? 'ALERT' : 'NORMAL',
                    color: _data.isOverload
                        ? Colors.red.shade600
                        : Colors.green.shade600,
                  ),
                  icon: Icons.warning_amber_outlined,
                ),
              ),
              const SizedBox(height: 10),
              _AnimatedGlassCard(
                child: _CostRow(
                  monthlyWidget: _AnimatedValue(
                    child: Text(
                      '₹ ${_data.totalChargeEstimated.toStringAsFixed(2)}',
                      key: ValueKey<double>(_data.totalChargeEstimated),
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  perDayWidget: _AnimatedValue(
                    child: Text(
                      '₹ ${_data.avgDailyCharge.toStringAsFixed(2)}',
                      key: ValueKey<double>(_data.avgDailyCharge),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ),

              // Navigation cards
              const SizedBox(height: 12),

              _AnimatedGlassCard(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Center(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const SettingsPage(),
                          ),
                        );
                      },
                      icon: const Icon(Icons.settings_outlined),
                      label: const Text('Settings'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          vertical: 14,
                          horizontal: 18,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        side: const BorderSide(color: Color(0xFFEDD5B3)),
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 24),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Automatic updates every 5s •',
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

/* ---------- Small helper widgets for animated values ---------- */

class _AnimatedValue extends StatelessWidget {
  final Widget child;
  final Duration duration;
  const _AnimatedValue({
    required this.child,
    this.duration = const Duration(milliseconds: 380),
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: duration,
      transitionBuilder: (child, anim) {
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(scale: anim, child: child),
        );
      },
      child: child,
    );
  }
}

class _BadgedAnimated extends StatelessWidget {
  final String keyVal;
  final String text;
  final Color color;
  const _BadgedAnimated({
    required this.keyVal,
    required this.text,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 360),
      child: Container(
        key: ValueKey<String>(keyVal),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          text,
          style: TextStyle(color: color, fontWeight: FontWeight.w700),
        ),
      ),
      transitionBuilder: (child, anim) =>
          FadeTransition(opacity: anim, child: child),
    );
  }
}

/* ---------- Reusable polished widgets ---------- */

class _AnimatedGlassCard extends StatelessWidget {
  final Widget child;
  const _AnimatedGlassCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.72),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFF3C6A2).withOpacity(0.14),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
            border: Border.all(color: const Color(0xFFFDE7D1)),
          ),
          child: child,
        ),
      ),
    );
  }
}

class _StatusRow extends StatelessWidget {
  final String title;
  final Widget labelWidget;
  final Widget badgeWidget;
  final IconData icon;

  const _StatusRow({
    required this.title,
    required this.labelWidget,
    required this.badgeWidget,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.02),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: Theme.of(context).colorScheme.primary,
              size: 28,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.toUpperCase(),
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFFA16207),
                  ),
                ),
                const SizedBox(height: 6),
                labelWidget,
                const SizedBox(height: 6),
                Row(children: [badgeWidget]),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CostRow extends StatelessWidget {
  final Widget monthlyWidget;
  final Widget perDayWidget;
  const _CostRow({required this.monthlyWidget, required this.perDayWidget});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Average Cost & Monthly Estimate',
            style: TextStyle(
              fontSize: 11,
              color: Color(0xFFA16207),
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Estimated Monthly Charge',
            style: TextStyle(fontSize: 11, color: Color(0xFF78716C)),
          ),
          const SizedBox(height: 6),
          monthlyWidget,
          const SizedBox(height: 12),
          const Text(
            'Average Cost Per Day',
            style: TextStyle(fontSize: 11, color: Color(0xFF78716C)),
          ),
          const SizedBox(height: 6),
          perDayWidget,
        ],
      ),
    );
  }
}

/* ---------- Header summary card ---------- */
class _HeaderCard extends StatelessWidget {
  final DashboardData data;
  const _HeaderCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final fmt = DateFormat('EEE, d MMM • hh:mm a');
    return _AnimatedGlassCard(
      child: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Row(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Overview', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 6),
                Text(
                  fmt.format(now),
                  style: const TextStyle(color: Color(0xFF6B635E)),
                ),
              ],
            ),
            const Spacer(),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Text(
                  'Today kWh',
                  style: TextStyle(color: Color(0xFF78716C)),
                ),
                Text(
                  '${data.totalKwhThisMonth.toStringAsFixed(1)} kWh',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Est. Bill',
                  style: TextStyle(color: Color(0xFF78716C)),
                ),
                Text(
                  '₹ ${data.totalChargeEstimated.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/* ================= Goals Page ================= */

class GoalsPage extends StatefulWidget {
  const GoalsPage({super.key});
  @override
  State<GoalsPage> createState() => _GoalsPageState();
}

class _GoalsPageState extends State<GoalsPage> {
  // Simulated current estimated cost (normally from backend)
  double _currentEstimated = 860.0;

  // Goal state (demo only - stored in memory)
  double _goal = 1200.0;
  final TextEditingController _controller = TextEditingController();

  // presets for quick selection
  final List<double> _presets = [800, 1000, 1200, 1500];

  @override
  void initState() {
    super.initState();
    _controller.text = _goal.toStringAsFixed(0);
    // in real app, fetch currentEstimated from backend every few seconds
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  double get _progress =>
      (_currentEstimated / (_goal <= 0 ? 1 : _goal)).clamp(0.0, 1.0);

  // simple projection: assuming linear usage so far this month
  // For demo, we simulate based on currentEstimated vs day-of-month
  String _projectionText() {
    final now = DateTime.now();
    final day = now.day;
    final daysInMonth = DateUtils.getDaysInMonth(now.year, now.month);
    // average so far:
    final avgSoFar = _currentEstimated / max(1, day);
    final projected = avgSoFar * daysInMonth;
    if (projected <= _goal) {
      final save = _goal - projected;
      return 'Projected bill ₹${projected.toStringAsFixed(0)} — On track (save ₹${save.toStringAsFixed(0)}).';
    } else {
      final over = projected - _goal;
      return 'Projected bill ₹${projected.toStringAsFixed(0)} — Over goal by ₹${over.toStringAsFixed(0)}.';
    }
  }

  List<String> _generateTips() {
    final tips = <String>[];
    if (_progress > 0.85) {
      tips.add(
        'High usage now — avoid heavy appliances during peak hours (6–9 PM).',
      );
      tips.add('Use delay/timer for washing machine or water heater.');
    } else if (_progress > 0.6) {
      tips.add('You are doing OK — small changes can secure the goal.');
      tips.add('Lower AC setpoint by 1–2°C or use fan where possible.');
    } else {
      tips.add('Good progress! Maintain current usage pattern.');
      tips.add('Consider eco-modes for large appliances.');
    }
    return tips;
  }

  void _saveGoalFromInput() {
    final text = _controller.text.replaceAll(',', '').trim();
    final v = double.tryParse(text);
    if (v != null && v > 0) {
      setState(() => _goal = v);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Goal saved')));
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Enter a valid goal')));
    }
  }

  void _resetGoal() {
    setState(() {
      _goal = 1200;
      _controller.text = _goal.toStringAsFixed(0);
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final tips = _generateTips();
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text('Energy Goals'),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _AnimatedGlassCard(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // circular progress
                          SizedBox(
                            width: 120,
                            height: 120,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                CircularProgressIndicator(
                                  value: _progress,
                                  strokeWidth: 12,
                                  color: _progress < 0.6
                                      ? Colors.green.shade600
                                      : (_progress < 0.9
                                            ? Colors.orange.shade700
                                            : Colors.red.shade600),
                                  backgroundColor: Colors.grey.withOpacity(
                                    0.12,
                                  ),
                                ),
                                Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      '${(_progress * 100).toStringAsFixed(0)}%',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    const Text(
                                      'of goal',
                                      style: TextStyle(fontSize: 12),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Monthly Goal',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFFA16207),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  '₹ ${_goal.toStringAsFixed(0)}',
                                  style: const TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                const Text(
                                  'Current estimate',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFF78716C),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  '₹ ${_currentEstimated.toStringAsFixed(0)}',
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                LinearProgressIndicator(
                                  value: _progress,
                                  minHeight: 8,
                                  backgroundColor: Colors.grey.withOpacity(
                                    0.12,
                                  ),
                                  color: _progress < 0.6
                                      ? Colors.green.shade600
                                      : (_progress < 0.9
                                            ? Colors.orange.shade700
                                            : Colors.red.shade600),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      // projection
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          _projectionText(),
                          style: theme.textTheme.bodyMedium,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              // set goal card
              _AnimatedGlassCard(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Set Monthly Goal (₹)',
                        style: TextStyle(
                          fontSize: 12,
                          color: Color(0xFFA16207),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _controller,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                hintText: 'Enter monthly budget',
                                isDense: true,
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          ElevatedButton(
                            onPressed: _saveGoalFromInput,
                            child: const Text('Save'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        children: _presets.map((p) {
                          return OutlinedButton(
                            onPressed: () {
                              setState(() {
                                _goal = p;
                                _controller.text = _goal.toStringAsFixed(0);
                              });
                            },
                            child: Text('₹${p.toStringAsFixed(0)}'),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          TextButton.icon(
                            onPressed: _resetGoal,
                            icon: const Icon(Icons.refresh_outlined),
                            label: const Text('Reset to default'),
                          ),
                          const SizedBox(width: 8),
                          TextButton.icon(
                            onPressed: () {
                              setState(() {
                                // demo: reduce estimated cost to simulate user actions
                                _currentEstimated = max(
                                  0,
                                  _currentEstimated - 50,
                                );
                              });
                            },
                            icon: const Icon(Icons.flash_on_outlined),
                            label: const Text('Quick save (simulate)'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              // tips card
              _AnimatedGlassCard(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Tips to reach your goal',
                        style: TextStyle(
                          fontSize: 12,
                          color: Color(0xFFA16207),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      for (var t in tips)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              Icon(
                                Icons.lightbulb_outline,
                                size: 18,
                                color: Colors.orange.shade400,
                              ),
                              const SizedBox(width: 8),
                              Expanded(child: Text(t)),
                            ],
                          ),
                        ),
                      const SizedBox(height: 6),
                      const Text(
                        'Tip: Use the Cost page to review your cost breakdown and identify high-cost appliances.',
                        style: TextStyle(
                          color: Color(0xFF78716C),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              // small explanation / legend
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Projection uses linear estimate based on usage so far this month.',
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

/* ================= Cost Pie Page (unchanged) ================= */

class CostPiePage extends StatefulWidget {
  const CostPiePage({super.key});
  @override
  State<CostPiePage> createState() => _CostPiePageState();
}

class _CostPiePageState extends State<CostPiePage> {
  double peak = 40, off = 50, fixed = 10;
  late Timer _timer;
  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(
      const Duration(seconds: 6),
      (_) => setState(_simulate),
    );
  }

  void _simulate() {
    final r = Random();
    peak = 30 + r.nextDouble() * 25;
    fixed = 5 + r.nextDouble() * 10;
    off = 100 - (peak + fixed);
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text('Cost Breakdown'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: _AnimatedGlassCard(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                const Text(
                  'Monthly Cost Breakdown',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                AspectRatio(
                  aspectRatio: 1.3,
                  child: PieChart(
                    PieChartData(
                      sections: [
                        PieChartSectionData(
                          value: peak,
                          title: 'Peak',
                          radius: 60,
                          color: const Color(0xFFE85A0F),
                        ),
                        PieChartSectionData(
                          value: off,
                          title: 'Off-peak',
                          radius: 50,
                          color: const Color(0xFF0EA5E9),
                        ),
                        PieChartSectionData(
                          value: fixed,
                          title: 'Fixed',
                          radius: 40,
                          color: const Color(0xFFFACC15),
                        ),
                      ],
                      sectionsSpace: 6,
                      centerSpaceRadius: 26,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Peak: ${peak.toStringAsFixed(1)}% • Off-peak: ${off.toStringAsFixed(1)}% • Fixed: ${fixed.toStringAsFixed(1)}%',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: const Center(
        child: Text('Settings coming soon', style: TextStyle(fontSize: 16)),
      ),
    );
  }
}

Widget navCard({
  required BuildContext context,
  required IconData icon,
  required String title,
  required Widget page,
}) {
  return InkWell(
    borderRadius: BorderRadius.circular(16),
    onTap: () {
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    },
    child: Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Icon(icon, size: 32),
            const SizedBox(width: 16),
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    ),
  );
}

/* ================= Data model ================= */

class DashboardData {
  final double voltage;
  final double current;
  final double power;
  final double totalKwhThisMonth;
  final double totalChargeEstimated;
  final double avgDailyCharge;
  final bool isPeak;
  final bool isOverload;

  DashboardData({
    required this.voltage,
    required this.current,
    required this.power,
    required this.totalKwhThisMonth,
    required this.totalChargeEstimated,
    required this.avgDailyCharge,
    required this.isPeak,
    required this.isOverload,
  });

  static DashboardData generateDummy() {
    final now = DateTime.now();
    final rnd = Random();
    final voltage = 210 + rnd.nextDouble() * 40;
    final current = 2 + rnd.nextDouble() * 6;
    final power = voltage * current;
    final totalKwh = 80 + rnd.nextDouble() * 120;
    final totalCharge = totalKwh * 6;
    return DashboardData(
      voltage: voltage,
      current: current,
      power: power,
      totalKwhThisMonth: totalKwh,
      totalChargeEstimated: totalCharge,
      avgDailyCharge: totalCharge / 30,
      isPeak: now.hour >= 18 && now.hour < 22,
      isOverload: power > 2000,
    );
  }
}
